def lambda_handler(event, context):
    return {"message": "Validation Lambda"}
